<h1><a href="{{ route('add.car') }}">manqanis damateba</a></h1>

<h2>manqanebis chamonatvali </h2>

@foreach($cars as $car)
    <h2>{{ $car->name }}</h2>
    <h4>make: {{ $car->make }}</h4>
    <h4>model: {{ $car->model }}</h4>
    <h4>license_number: {{ $car->license_number }}</h4>
    <h4>weight: {{ $car->weight }}</h4>
    <h4>registration_year: {{ $car->registration_year }}</h4>
    <h4>asaki: {{ $car->asaki->y }}</h4>
    <a href="{{route('edit.car',['car' => $car->id])}}">edit</a>
    <form action="{{route('car.delete',['car' => $car->id])}}" method="POSt">
        @csrf
        <button type="submit">delete</button>
    </form>
@endforeach
